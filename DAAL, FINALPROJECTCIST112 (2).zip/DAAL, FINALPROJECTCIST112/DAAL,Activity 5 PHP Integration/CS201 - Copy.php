<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-color: #1c1c1c;
        color: #ff4444;
        font-family: Arial, sans-serif;
    }
    .login-container {
        margin-top: 100px;
    }
    .login-form {
        background-color: #1c1c1c; 
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.5);
    }
    .form-control:focus {
        box-shadow: none;
    }
    .btn-login {
        background-color: #ff4444; 
        border: none;
        color: #1c1c1c;
        transition: all 0.3s;
    }
    .btn-login:hover {
        background-color: #ff3333;
        color: #1c1c1c;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4 login-container">
                <h2 class="text-center text-white mb-4">Login</h2>
                <div class="login-form">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label for="email" class="text-white">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password" class="text-white">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-block btn-login">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "post") {
    $email = $_POST['email']; 
    $password = $_POST['password']; 

    if (empty($email) || empty($password)) {
        echo "<script>alert('Please enter both email and password.');</script>";
    } else {
        if ($email === "wybendaal123@gmail.com" && $password === "123456") { 
            echo "<script>alert('Login successful.');</script>";  
            echo "<script>window.location.href = 'CONVERTER.html';</script>";
            exit(); 
        } else {
            echo "<script>alert('Invalid email or password.');</script>";
        }
    }
}
?>