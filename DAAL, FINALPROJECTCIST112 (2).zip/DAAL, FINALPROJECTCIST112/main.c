#include <stdio.h>
#define MAX_SET_SIZE 10
#define MAX_UNIVERSAL_SIZE 20

#define RESET       "\x1B[0m"
#define YELLOW      "\x1B[33m"
#include <conio.h>
// MY FINAL PROJECT CSIT112  WYBEN CASQUEJO DAAL




int setA[MAX_SET_SIZE], setB[MAX_SET_SIZE], universalSet[MAX_UNIVERSAL_SIZE];
int sizeA = 0, sizeB = 0, sizeUniversal = 0;
// THIS IS THE PROTOTYPE FUCNTION
void inputSets();
void inputUniversalSet();
void unionSets();
void intersectionSets();
void complementA();
void complementB();
void displaySets();
void displayUniversalSet();
 
int main() {
    int choice;
            printf("---------SET OPERATIONS---------\n");
            printf("Programmer: WYBEN CASQUEJO DAAL--------\n");

    do {     
         
        printf("\nMAIN MENU\n");
        printf("1. Input Sets A and B\n");
        printf("2. Input Universal Set\n");
        printf("3. Union of Sets A and B\n");
        printf("4. Intersection of Sets A and B\n");
        printf("5. Complement of Set A\n");
        printf("6. Complement of Set B\n");
        printf("7. Display Sets A and B\n");
        printf("8. Display Universal Set\n");
        printf("9. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                inputSets();
                break;
            case 2:
                inputUniversalSet();
                break;
            case 3:
                unionSets();
                break;
            case 4:
                intersectionSets();
                break;
            case 5:
                complementA();
                break;
            case 6:
                complementB();
                break;
            case 7:
                displaySets();
                break;
            case 8:
                displayUniversalSet();
                break;
            case 9:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 9);

    return 0;
}
 
 
void inputSets() {
    int i, num, setSize;

    printf("Enter the size of Set A (up to %d elements): ", MAX_SET_SIZE);
    scanf("%d", &setSize);
    if (setSize > MAX_SET_SIZE) {
        printf("Invalid size. Maximum allowed size is %d.\n", MAX_SET_SIZE);
        return;
    }
    printf("Input Set A:\n");
    for (i = 0; i < setSize; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &num);
        if (num < 1 || num > 20) {
            printf("Error: Input must be between 1 and 20.\n");
            i--;
        } else {
            setA[i] = num;
        }
    }
    sizeA = setSize;

    printf("Enter the size of Set B (up to %d elements): ", MAX_SET_SIZE);
    scanf("%d", &setSize);
    if (setSize > MAX_SET_SIZE) {
        printf("Invalid size. Maximum allowed size is %d.\n", MAX_SET_SIZE);
        return;
    }
    printf("Input Set B:\n");
    for (i = 0; i < setSize; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &num);
        if (num < 1 || num > 20) {
            printf("Error: Input must be between 1 and 20.\n");
            i--;
        } else {
            setB[i] = num;
        }
    }
    sizeB = setSize;
}


void inputUniversalSet() {
    int i, num, setSize;

    printf("Enter the size of the Universal Set (up to %d elements): ", MAX_UNIVERSAL_SIZE);
    scanf("%d", &setSize);
    if(setSize > MAX_UNIVERSAL_SIZE){
    	printf("Invalid size!!!");
    	return;
}
	
			    printf("Input Universal Set:\n");
    for (i = 0; i < setSize; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &num);
        if (num < 1 || num > 20) {
            printf("Error: Input must be between 1 and 20.\n");
            i--;
        } else {
            universalSet[i] = num;
        }
    }
    sizeUniversal = setSize;
}

void unionSets() {
    int i, j, k;
    int unionSet[MAX_UNIVERSAL_SIZE];
    int sizeUnion = 0;

    for (i = 0; i < sizeA; i++) {
        unionSet[sizeUnion++] = setA[i];
    }

    for (j = 0; j < sizeB; j++) {
        int exists = 0;
        for (i = 0; i < sizeA; i++) {
            if (setB[j] == setA[i]) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            unionSet[sizeUnion++] = setB[j];
        }
    }

    printf("Union of Sets A and B: {");
    for (k = 0; k < sizeUnion; k++) {
        printf("%d", unionSet[k]);
        if (k < sizeUnion - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

void intersectionSets() {
    int i, j, k;
    int intersectionSet[MAX_UNIVERSAL_SIZE];
    int sizeIntersection = 0;

    for (i = 0; i < sizeA; i++) {
        for (j = 0; j < sizeB; j++) {
            if (setA[i] == setB[j]) {
                intersectionSet[sizeIntersection++] = setA[i];
                break;
            }
        }
    }

    printf("Intersection of Sets A and B: {");
    for (k = 0; k < sizeIntersection; k++) {
        printf("%d", intersectionSet[k]);
        if (k < sizeIntersection - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

void complementA() {
    int i, j, k;
    int complement[MAX_UNIVERSAL_SIZE];
    int sizeComplement = 0;

    for (i = 0; i < sizeUniversal; i++) {
        int exists = 0;
        for (j = 0; j < sizeA; j++) {
            if (universalSet[i] == setA[j]) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            complement[sizeComplement++] = universalSet[i];
        }
    }

    printf("Complement of Set A: {");
    for (k = 0; k < sizeComplement; k++) {
        printf("%d", complement[k]);
        if (k < sizeComplement - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

void complementB() {
    int i, j, k;
    int complement[MAX_UNIVERSAL_SIZE];
    int sizeComplement = 0;

    for (i = 0; i < sizeUniversal; i++) {
        int exists = 0;
        for (j = 0; j < sizeB; j++) {
            if (universalSet[i] == setB[j]) {
                exists = 1;
                break;
            }
        }
        if (!exists) {
            complement[sizeComplement++] = universalSet[i];
        }
    }

    printf("Complement of Set B: {");
    for (k = 0; k < sizeComplement; k++) {
        printf("%d", complement[k]);
        if (k < sizeComplement - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

void displaySets() {
    int i;

    printf("Set A: {");
    for (i = 0; i < sizeA; i++) {
        printf("%d", setA[i]);
        if (i < sizeA - 1) {
            printf(", ");
        }
    }
    printf("}\n");

    printf("Set B: {");
    for (i = 0; i < sizeB; i++) {
        printf("%d", setB[i]);
        if (i < sizeB - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

void displayUniversalSet() {
    int i;

    printf("Universal Set: {");
    for (i = 0; i < sizeUniversal; i++) {
        printf("%d", universalSet[i]);
        if (i < sizeUniversal - 1) {
            printf(", ");
        }
    }
    printf("}\n");
}

// END OF THE CODE 


