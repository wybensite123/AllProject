    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package activity30;

/**
 *
 * @author Administrator
 */
public interface ExceptionInterface {
    void compute(int num1, int num2);
    void nameDisplay(int nameLength) throws NullPointerException;
}
