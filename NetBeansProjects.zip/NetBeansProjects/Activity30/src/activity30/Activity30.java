/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package activity30;

/**
 *
 * @author Administrator
 */
import java.util.Scanner;

public class Activity30 {
    public static void main(String[] args) {
          ExceptionMethods obj = new ExceptionMethods();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Press 1 - Throw");
            System.out.println("Press 2 - Throws");
            System.out.println("Press 3 - Exit");
            System.out.print("Enter Choice: ");
            choice = scanner.nextInt();

            switch(choice) {
                case 1:
                    try {
                        System.out.print("Enter numerator: ");
                        int num1 = scanner.nextInt();
                        System.out.print("Enter denominator: ");
                        int num2 = scanner.nextInt();
                        obj.compute(num1, num2);
                    } catch (ArithmeticException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 2:
                    try {
                        System.out.print("Enter your name: ");
                       int nameLength = scanner.nextInt();
                        obj.nameDisplay(nameLength);
                    } catch (NullPointerException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    System.out.println("Exiting the program.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 3);

        scanner.close();
    }
    
}
