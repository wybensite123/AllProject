/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package activity30;

/**
 *
 * @author Administrator
 */


public class ExceptionMethods implements ExceptionInterface {

  
    @Override
    public void compute(int num1, int num2) {
        if (num2 < 0) {
            throw new ArithmeticException("You cannot divide a number by zero.");
        } else {
            int res = num1 / num2;
            System.out.println("The quotient of " + num1 + " and " + num2 + " is: " + res);
        }
    }

    
    @Override
    public void nameDisplay(int nameLength) throws NullPointerException {
        
        System.out.println("Your name length is " + nameLength);
    }
}
