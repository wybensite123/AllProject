/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actitvity29;

/**
 *
 * @author Administrator
 */
import java.util.Scanner;
public class Actitvity29 {

    
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        ExceptionHandler handler = new ExceptionHandlerImpl();

        while (true) {
            System.out.println("Press 1 - Arithmetic Exception");
            System.out.println("Press 2 - ArrayIndexOutOfBounds Exception");
            System.out.println("Press 3 - FileNotFound Exception");
            System.out.println("Press 4 - Null Pointer Exception");
            System.out.println("Press 5 - Number Format Exception");
            System.out.println("Press 6 - String Index Out Of Bound Exception");
            System.out.println("Press 7 - Exit");
            System.out.print("Enter Choice: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                if (choice == 7) {
                    System.out.println("Exiting...");
                    break;
                }
                switch (choice) {
                    case 1:
                        handler.handleArithmeticException();
                        break;
                    case 2:
                        handler.handleArrayIndexOutOfBoundsException();
                        break;
                    case 3:
                        handler.handleFileNotFoundException();
                        break;
                    case 4:
                        handler.handleNullPointerException();
                        break;
                    case 5:
                        handler.handleNumberFormatException();
                        break;
                    case 6:
                        handler.handleStringIndexOutOfBoundsException();
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        scanner.close();
    }
    
}
