/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actitvity29;

/**
 *
 * @author Administrator
 */
public interface ExceptionHandler {
    void handleArithmeticException();
    void handleArrayIndexOutOfBoundsException();
    void handleFileNotFoundException();
    void handleNullPointerException();
    void handleNumberFormatException();
    void handleStringIndexOutOfBoundsException();
}
