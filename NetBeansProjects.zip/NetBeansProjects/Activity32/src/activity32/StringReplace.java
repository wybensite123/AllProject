/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package activity32;

/**
 *
 * @author Administrator
 */
 abstract public class StringReplace {
    abstract void setText1(String str1);
    abstract void setText2(String str2);
    abstract void setDel1(String del1);
    abstract void setDel2(String del2);
    abstract String getText1();
    abstract String getText2();
    abstract String getDel1();
    abstract String getDel2();
    abstract void printStr(String str1, String str2, String del1, String del2);
}
