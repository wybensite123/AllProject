/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package activity32;

/**
 *
 * @author Administrator
 */
import java.util.*;
public class Activity32 {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        StringReplaced sr = new StringReplaced();
        
        System.out.print("Enter text 1: ");
        String text1 = sc.nextLine();
        sr.setText1(text1);
        
        System.out.print("Enter text 2: ");
        String text2 = sc.nextLine();
        sr.setText2(text2);
        
        System.out.print("Enter del 1: ");
        String del1 = sc.nextLine();
        sr.setDel1(del1);
        
        System.out.print("Enter del 2: ");
        String del2 = sc.nextLine();
        sr.setDel2(del2);
        
        System.out.println("Before replacement: ");
        System.out.println(text1);
        System.out.println(text2);
        sr.printStr(text1, text2, del1, del2);
    }
    
}
