/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package activity32;

/**
 *
 * @author Administrator
 */
public class StringReplaced extends StringReplace {
    private String str1, str2, del1, del2;
    @Override
    public void setText1(String str){
        str1 = str;
    }
    @Override
    public void setText2(String str){
        str2 = str;
    }
    @Override
    public void setDel1(String del){
        del1 = del;
    }
    @Override
    public void setDel2(String del){
        del2 = del;
    }
    @Override
    public String getText1(){
        return str1;
    }
    @Override
    public String getText2(){
        return str2;
    }
    @Override
    public String getDel1(){
        return del1;
    }
    @Override
    public String getDel2(){
        return del2;
    }
    @Override
    public void printStr(String str1, String str2, String del1, String del2){
        String textReplaced1 = str1.replace(""+del1+"", " ");
        String textReplaced2 = str2.replaceAll("["+del2+"]", "");
        System.out.println("After replacement: ");
        System.out.println(textReplaced1);
        System.out.println(textReplaced2);
    }
}